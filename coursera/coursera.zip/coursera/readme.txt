Terminal commands
To install requirements.txt for running the script:
  pip install -r /path/to/requirements.txt

To run the scraper :
  scrapy crawl scraper
