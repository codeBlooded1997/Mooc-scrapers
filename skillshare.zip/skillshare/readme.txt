TERMINAL COMMANDS

To install required packages :
    pip install -r /path/to/requirements.txt

To tun the scraper: (Change directory to where the python file skillshare_bs.py exists)
    python skillshare_bs.py

This is a command-line application so the result will be displayed in the command-line(No csv output)
